import { useEffect, useState } from 'react'
import { Layers } from 'lucide-react'
import { Card } from '@/components/ui/Card'
import {
  CompanyVsSectorNormalizedChart,
  SectorQuarterlyTrendChart,
  SectorRealGrowthChart,
  SectorValueAddedTrendChart,
  VaGrowthBarsChart,
} from '@/features/analyse/components/charts/SectorCharts'
import { formatSectorAmount, formatSignedPct } from '@/lib/sectorFormat'
import { apiGet, apiPost } from '@/services/api/client'
import type { SectorAnalysisData } from '@/types/analyse'

type Props = {
  data?: SectorAnalysisData | null
  dossierId?: string
}

export function SectorAnalysisTab({ data, dossierId }: Props) {
  const [busy, setBusy] = useState(false)
  const [local, setLocal] = useState(data)
  const analysis = local ?? data

  useEffect(() => {
    setLocal(data)
  }, [data])

  useEffect(() => {
    if (!dossierId) return
    let cancelled = false
    apiGet<SectorAnalysisData>(`/dossiers/${encodeURIComponent(dossierId)}/sector-analysis`)
      .then((next) => {
        if (!cancelled) setLocal(next)
      })
      .catch(() => {
        /* le workspace reste la source de repli */
      })
    return () => {
      cancelled = true
    }
  }, [dossierId])

  async function refresh() {
    if (!dossierId) return
    setBusy(true)
    try {
      await apiPost(`/sector-data/sync`)
      const next = await apiGet<SectorAnalysisData>(`/dossiers/${encodeURIComponent(dossierId)}/sector-analysis`)
      setLocal(next)
    } finally {
      setBusy(false)
    }
  }

  if (!analysis || analysis.status === 'UNAVAILABLE') {
    return (
      <Card className="p-5">
        <div className="text-[13px] font-bold text-slate-900">Analyse sectorielle</div>
        <p className="m-0 mt-2 text-[13px] text-wb-muted">
          {analysis?.warnings?.[0] || 'Analyse sectorielle temporairement indisponible.'}
        </p>
      </Card>
    )
  }

  if (analysis.status === 'MAPPING_REVIEW_REQUIRED') {
    return (
      <Card className="p-5">
        <div className="text-[13px] font-bold text-slate-900">Analyse sectorielle</div>
        <p className="m-0 mt-2 text-[13px] text-wb-muted">
          Le secteur de l’entreprise n’a pas pu être rapproché d’une branche HCP de manière fiable.
        </p>
        <p className="m-0 mt-1 text-[12px] text-wb-faint">Classification sectorielle à confirmer.</p>
      </Card>
    )
  }

  const fresh = analysis.dataFreshness?.status
  const badge =
    fresh === 'FRESH' ? 'À jour' : fresh === 'UNAVAILABLE' ? 'Indisponible' : 'Données en cache'
  const h = analysis.headline || {}
  const companyMissing = (analysis.companyAnnual || []).every((p) => !p.vaUsable)

  return (
    <div className="flex flex-col gap-4">
      <Card className="p-5">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div className="flex items-start gap-2.5">
            <span className="flex h-9 w-9 items-center justify-center rounded-[10px] bg-wb-accent-soft text-wb-accent">
              <Layers size={16} strokeWidth={1.8} />
            </span>
            <div>
              <div className="text-[13px] font-bold text-slate-900">Analyse sectorielle</div>
              <div className="mt-1 text-[12.5px] text-slate-700">Secteur {analysis.sector?.label || '—'}</div>
              <div className="mt-0.5 text-[11.5px] text-wb-faint">
                Source HCP — Comptes nationaux Base 2014 · Dernière donnée {h.latestYear ?? '—'}
                {analysis.dataFreshness?.lastSyncAt
                  ? ` · Mise à jour locale ${new Date(analysis.dataFreshness.lastSyncAt).toLocaleString('fr-FR')}`
                  : ''}
              </div>
            </div>
          </div>
          <span
            className={`rounded-full px-3 py-1 text-[11.5px] font-bold ${
              fresh === 'FRESH' ? 'bg-[#ECFDF5] text-[#15803D]' : 'bg-[#FFF8EC] text-[#B45309]'
            }`}
          >
            {badge}
          </span>
        </div>
        <p className="m-0 mt-3 border-t border-[#F1F2F4] pt-3 text-[12.5px] text-wb-muted">
          {analysis.scoring?.note || 'Non intégrée au score — politique sectorielle non calibrée.'}
        </p>
      </Card>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Kpi label="VA sectorielle" value={formatSectorAmount(h.latestSectorVa, h.latestUnit)} sub={String(h.latestYear ?? '')} />
        <Kpi label="Variation nominale N/N-1" value={formatSignedPct(h.nominalGrowthYoy)} />
        <Kpi label="Croissance réelle" value={formatSignedPct(h.realGrowthYoy)} />
        <Kpi label="Tendance 3 ans" value={h.cagr3y == null ? '—' : `${formatSignedPct(h.cagr3y)} CAGR`} />
      </div>

      <Card className="p-5">
        <div className="text-[13px] font-bold text-slate-900">Valeur ajoutée sectorielle — évolution</div>
        <div className="mb-3 text-[11.5px] text-wb-faint">
          {analysis.sector?.label} · Millions de MAD · prix courants
        </div>
        <SectorValueAddedTrendChart series={analysis.sectorAnnualCurrent || []} sectorLabel={analysis.sector?.label} />
      </Card>

      <Card className="p-5">
        <div className="text-[13px] font-bold text-slate-900">Evolution relative — entreprise vs secteur</div>
        <div className="mb-3 text-[11.5px] text-wb-faint">Indice base 100 · Valeur ajoutée nominale</div>
        {companyMissing || (analysis.normalizedComparison || []).length === 0 ? (
          <p className="m-0 text-[13px] text-wb-muted">Analyse de la liasse requise</p>
        ) : (
          <CompanyVsSectorNormalizedChart series={analysis.normalizedComparison} />
        )}
      </Card>

      <Card className="p-5">
        <div className="text-[13px] font-bold text-slate-900">Croissance de la valeur ajoutée</div>
        <VaGrowthBarsChart rows={analysis.growthComparison || []} />
        {companyMissing && <p className="m-0 mt-2 text-[12px] text-wb-muted">Analyse de la liasse requise</p>}
        <div className="mt-4 overflow-x-auto">
          <table className="w-full border-collapse text-left text-[12px]">
            <thead>
              <tr className="text-[10.5px] uppercase tracking-wide text-wb-faint">
                <th className="pb-2 font-semibold">Année</th>
                <th className="pb-2 font-semibold">VA entreprise</th>
                <th className="pb-2 font-semibold">Croissance entreprise</th>
                <th className="pb-2 font-semibold">VA secteur</th>
                <th className="pb-2 font-semibold">Croissance secteur</th>
                <th className="pb-2 font-semibold">Écart</th>
              </tr>
            </thead>
            <tbody>
              {(analysis.growthComparison || []).map((row) => {
                const company = (analysis.companyAnnual || []).find((c) => c.year === row.year)
                const sector = (analysis.sectorAnnualCurrent || []).find((c) => c.year === row.year)
                return (
                  <tr key={row.year} className="border-t border-[#F1F2F4]">
                    <td className="py-2 font-semibold">{row.year}</td>
                    <td>{company?.vaUsable ? formatSectorAmount(company.va, 'MAD') : '—'}</td>
                    <td>{formatSignedPct(row.companyGrowth)}</td>
                    <td>{formatSectorAmount(sector?.value ?? null, sector?.unit)}</td>
                    <td>{formatSignedPct(row.sectorGrowth)}</td>
                    <td>{row.gapPp == null ? '—' : `${row.gapPp > 0 ? '+' : ''}${row.gapPp.toFixed(1).replace('.', ',')} pts`}</td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      </Card>

      {(analysis.sectorAnnualReal || []).length > 0 && (
        <Card className="p-5">
          <div className="text-[13px] font-bold text-slate-900">Conjoncture sectorielle réelle</div>
          <p className="m-0 mb-3 text-[11.5px] text-wb-faint">{analysis.realGrowthNote}</p>
          <SectorRealGrowthChart series={analysis.sectorAnnualReal} />
        </Card>
      )}

      {(analysis.sectorQuarterly || []).length > 0 && (
        <Card className="p-5">
          <div className="text-[13px] font-bold text-slate-900">Dynamique trimestrielle</div>
          <div className="mb-2 text-[11.5px] text-wb-faint">HCP — CVS Base 2014</div>
          <SectorQuarterlyTrendChart series={analysis.sectorQuarterly} />
        </Card>
      )}

      <Card className="p-5">
        <div className="mb-3 text-[13px] font-bold text-slate-900">Entreprise vs secteur</div>
        {(analysis.comparableIndicators || []).map((ind) => (
          <div key={ind.code} className="flex flex-wrap justify-between gap-2 border-t border-[#F1F2F4] py-2 text-[12.5px]">
            <span className="font-semibold text-slate-800">{ind.label}</span>
            <span>Entreprise {ind.companyValue == null ? 'Analyse requise' : formatSignedPct(ind.companyValue)}</span>
            <span>Secteur {formatSignedPct(ind.sectorValue)}</span>
            <span className="text-wb-faint">{ind.source}</span>
          </div>
        ))}
      </Card>

      <Card className="p-5">
        <div className="text-[13px] font-bold text-slate-900">Qualité et provenance des données</div>
        <ul className="mt-2 list-none space-y-1 p-0 text-[12.5px] text-wb-muted">
          <li>Source : HCP</li>
          <li>Dataset : Valeurs ajoutées à prix courants</li>
          <li>Base : 2014</li>
          <li>Fréquence : Annuelle</li>
          <li>Dernière période : {analysis.dataFreshness?.latestObservationPeriod || h.latestYear || '—'}</li>
          <li>Dernière synchronisation : {analysis.dataFreshness?.lastSyncAt || '—'}</li>
          <li>
            Version : {(analysis.dataFreshness?.datasetVersions?.[0]?.sha256 || '').slice(0, 12) || '—'}
          </li>
          <li>État : {badge}</li>
        </ul>
        <button
          type="button"
          onClick={refresh}
          className="mt-3 rounded-[8px] border border-wb-line px-3 py-1.5 text-[12px] font-semibold text-slate-700"
        >
          {busy ? 'Actualisation…' : 'Actualiser les données sectorielles'}
        </button>
      </Card>
    </div>
  )
}

function Kpi({ label, value, sub }: { label: string; value: string; sub?: string }) {
  return (
    <Card className="p-4">
      <div className="text-[10.5px] uppercase tracking-[0.03em] text-wb-faint">{label}</div>
      <div className="mt-1.5 text-[18px] font-extrabold tabular-nums text-slate-900">{value}</div>
      {sub ? <div className="mt-1 text-[11px] text-wb-faint">{sub}</div> : null}
    </Card>
  )
}

export { SectorAnalysisTab as BenchmarkTab }

import { describe, expect, it } from 'vitest'
import { formatSectorAmount, formatSignedPct } from '@/lib/sectorFormat'

describe('labels analyse', () => {
  it('Analyse sectorielle et Comportement bancaire', () => {
    const tabs = [
      { id: 'benchmark', label: 'Analyse sectorielle' },
      { id: 'comportement', label: 'Comportement bancaire' },
    ]
    expect(tabs.find((t) => t.id === 'benchmark')?.label).toBe('Analyse sectorielle')
    expect(tabs.find((t) => t.id === 'comportement')?.label).toBe('Comportement bancaire')
  })
})

describe('formatters sectoriels', () => {
  it('formate millions et milliards sans double suffixe', () => {
    expect(formatSectorAmount(121082, 'M MAD')).toContain('Md MAD')
    expect(formatSectorAmount(40577233, 'MAD')).toContain('M MAD')
    expect(formatSectorAmount(950000, 'MAD')).toContain('M MAD')
    expect(formatSectorAmount(null)).toBe('—')
  })
})

describe('score sectoriel', () => {
  it('aucun faux score 0', () => {
    const scoring = { status: 'NOT_CALIBRATED' as const, includedInFinalScore: false, score: null as number | null }
    expect(scoring.score).toBeNull()
    expect(scoring.includedInFinalScore).toBe(false)
  })
})

describe('états sectoriels', () => {
  it('freshness stale', () => {
    expect('STALE').not.toBe('FRESH')
  })
  it('mapping review', () => {
    const status = 'MAPPING_REVIEW_REQUIRED'
    expect(status).toBe('MAPPING_REVIEW_REQUIRED')
  })
  it('entreprise absente', () => {
    const msg = 'Analyse requise'
    expect(msg).toContain('Analyse requise')
  })
})

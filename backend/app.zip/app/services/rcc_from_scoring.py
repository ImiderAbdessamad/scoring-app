"""Projection des dossiers scoring WFB vers la file RCC."""
from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from typing import Any

from app.schemas.analyse import (
    AccountingControlView,
    CompanyInfo,
    DocumentSummary,
    ExtractedField,
    ExtractionSummary,
    IdentityInfo,
    RCC_ELEMENTS,
    SCORING_EXTRA_ELEMENTS,
    ScoringAnalysisResult,
)
from app.services.rcc_dossier_store import RccDossier, rcc_dossier_store
from app.services.rcc_projection import build_identite, clean_activite, project_rcc_result

logger = logging.getLogger(__name__)

_SCORING_STATUS = {
    "pending": "pending",
    "analyzing": "pending",
    "review": "pending",
    "approved": "validated",
    "validated": "validated",
    "rejected": "rejected",
    "escalated": "escalated",
}


def _iso(value: str | None) -> str:
    if not value:
        return datetime.now(timezone.utc).isoformat()
    for fmt in ("%d/%m/%Y", "%Y-%m-%d", "%Y-%m-%dT%H:%M:%S"):
        try:
            parsed = datetime.strptime(value[:19], fmt)
            return parsed.replace(tzinfo=timezone.utc).isoformat()
        except ValueError:
            continue
    return datetime.now(timezone.utc).isoformat()


def _liasse_file(record) -> Any:
    files = list(record.files or [])
    for item in files:
        name = (item.name or "").lower()
        if item.category in {"liasse", "documents"} or name.endswith(".pdf"):
            if "proforma" in name:
                continue
            return item
    return files[0] if files else None


def _load_audit_result(record) -> ScoringAnalysisResult | None:
    from app.db.repositories import analysis_run_repository
    from app.services import minio_storage

    try:
        runs = analysis_run_repository.list_for_dossier(record.id)
    except Exception:
        runs = []
    for run in runs:
        key = getattr(run, "full_audit_object_key", None)
        if not key:
            continue
        try:
            raw = minio_storage.download_bytes(key)
            return ScoringAnalysisResult.model_validate(json.loads(raw.decode("utf-8")))
        except Exception:
            logger.warning("Audit V6 illisible pour %s", record.id)
    return None


def scoring_analysis_result(record) -> ScoringAnalysisResult | None:
    from app.services.analyse_job_store import job_store

    job = job_store.get_for_dossier(record.id)
    if job is not None and job.result is not None:
        return job.result
    audited = _load_audit_result(record)
    if audited is not None:
        return audited
    return result_from_workspace(record)


_FIELD_META = {code: (number, label, source) for number, code, label, source in (*RCC_ELEMENTS, *SCORING_EXTRA_ELEMENTS)}


def result_from_workspace(record) -> ScoringAnalysisResult | None:
    analyse = record.analyse or {}
    statements = analyse.get("financialStatements") or {}
    rows: list[dict[str, Any]] = []
    for group in ("actif", "passif", "cpc", "esg", "synthese"):
        rows.extend(statements.get(group) or [])
    if not rows:
        return None
    fields: list[ExtractedField] = []
    for row in rows:
        code = row.get("code")
        if not code:
            continue
        meta = _FIELD_META.get(code, (0, row.get("label") or code, row.get("source") or ""))
        value = row.get("n")
        status = row.get("nStatus") or ("confirmed" if value is not None else "missing")
        fields.append(
            ExtractedField(
                number=meta[0] or 1,
                code=code,
                label=row.get("label") or meta[1],
                source=row.get("source") or meta[2],
                value=value,
                value_n1=row.get("n1"),
                status=status,
                confidence=float(row.get("confidence") or 0),
                evidence=row.get("evidence") or [],
            )
        )
    header = analyse.get("header") or {}
    period = analyse.get("period") or {}
    identity = IdentityInfo(
        identifiant_fiscal=record.identifiantFiscal or None,
        ice=record.ice or None,
        raison_sociale=header.get("companyName") or record.name,
        activite=clean_activite(record.sector),
        secteur=clean_activite(record.sector),
        period_start=period.get("start"),
        period_end=period.get("end"),
    )
    company = CompanyInfo(
        raison_sociale=identity.raison_sociale,
        ice=identity.ice,
        identifiant_fiscal=identity.identifiant_fiscal,
        rc=record.rc or None,
    )
    controls = []
    for item in analyse.get("controls") or []:
        try:
            controls.append(AccountingControlView.model_validate(item))
        except Exception:
            continue
    return ScoringAnalysisResult(
        document=DocumentSummary(
            filename=_liasse_file(record).name if _liasse_file(record) else f"{record.id}.pdf",
            pages_total=0,
            pages_processed=0,
            pages_skipped=0,
            pages_failed=0,
            company=company,
            identity=identity,
        ),
        extraction=ExtractionSummary(model="v6"),
        fields=fields,
        completeness_pct=float((analyse.get("scoring") or {}).get("dossierCompletenessPct") or 0),
        controls=controls,
    )


def _has_numeric_fields(dossier: RccDossier) -> bool:
    for item in (dossier.result or {}).get("fields") or []:
        if item.get("value") is not None or item.get("value_n1") is not None:
            return True
    return False


def _stub_result(record) -> ScoringAnalysisResult:
    header = (record.analyse or {}).get("header") or {}
    period = (record.analyse or {}).get("period") or {}
    identity = IdentityInfo(
        identifiant_fiscal=record.identifiantFiscal or None,
        ice=record.ice or None,
        raison_sociale=header.get("companyName") or record.name,
        activite=clean_activite(record.sector),
        secteur=clean_activite(record.sector),
        period_start=period.get("start"),
        period_end=period.get("end"),
    )
    company = CompanyInfo(
        raison_sociale=identity.raison_sociale,
        ice=identity.ice,
        identifiant_fiscal=identity.identifiant_fiscal,
        rc=record.rc or None,
    )
    return ScoringAnalysisResult(
        document=DocumentSummary(
            filename=_liasse_file(record).name if _liasse_file(record) else f"{record.id}.pdf",
            pages_total=0,
            pages_processed=0,
            pages_skipped=0,
            pages_failed=0,
            company=company,
            identity=identity,
        ),
        extraction=ExtractionSummary(model="v6"),
        fields=[],
        completeness_pct=float(((record.analyse or {}).get("scoring") or {}).get("dossierCompletenessPct") or 0),
    )


def _pdf_bytes(record) -> bytes | None:
    from app.services import minio_storage

    item = _liasse_file(record)
    if item is None:
        return None
    try:
        return minio_storage.download_bytes(item.objectKey)
    except Exception:
        logger.warning("PDF scoring introuvable pour %s", record.id)
        return None


def import_scoring_record(record) -> RccDossier:
    existing = rcc_dossier_store.get(record.id)
    result = scoring_analysis_result(record) or _stub_result(record)
    projected = project_rcc_result(result)
    identite = projected.get("identite") or build_identite(result)
    if existing is not None and _has_numeric_fields(existing) and _has_numeric_fields(
        type("T", (), {"result": projected})()
    ):
        existing.result = projected
        existing.scoring_result = result
        existing.identite = identite
        existing.client_name = identite.get("raison_sociale") or existing.client_name
        existing.ice = identite.get("ice") or existing.ice
        existing.exercice_date = identite.get("period_end") or existing.exercice_date
        existing.sector = identite.get("activite") or clean_activite(record.sector) or existing.sector
        existing.completeness_pct = result.completeness_pct
        return existing
    if existing is not None and not _has_numeric_fields(
        type("T", (), {"result": projected})()
    ) and _has_numeric_fields(existing):
        return existing
    pdf_bytes = _pdf_bytes(record)
    pdf_path = None
    if pdf_bytes:
        pdf_path = str(rcc_dossier_store.save_pdf(record.id, pdf_bytes))
    job = None
    try:
        from app.services.analyse_job_store import job_store

        job = job_store.get_for_dossier(record.id)
    except Exception:
        job = None
    now = _iso(record.date)
    dossier = RccDossier(
        id=record.id,
        job_id=(job.job_id if job else record.analyseJobId),
        client_name=identite.get("raison_sociale") or record.name,
        ice=identite.get("ice") or record.ice,
        credit_amount=record.amount,
        exercice_date=identite.get("period_end"),
        status=_SCORING_STATUS.get(record.status, "pending"),
        created_at=now,
        updated_at=now,
        sector=identite.get("activite") or record.sector,
        filename=_liasse_file(record).name if _liasse_file(record) else None,
        pdf_path=pdf_path,
        completeness_pct=result.completeness_pct,
        result=projected,
        scoring_result=result,
        identite=identite,
        origin="scoring",
    )
    rcc_dossier_store.put(dossier)
    return dossier


def scoring_list_summaries() -> list[dict[str, Any]]:
    from app.services import dossier_store

    items = []
    for record in dossier_store.list_created():
        if rcc_dossier_store.get(record.id) is not None:
            continue
        scoring = (record.analyse or {}).get("scoring") or {}
        items.append(
            {
                "id": record.id,
                "job_id": record.analyseJobId,
                "client_name": record.name,
                "ice": record.ice or None,
                "credit_amount": record.amount,
                "exercice_date": ((record.analyse or {}).get("period") or {}).get("end"),
                "status": _SCORING_STATUS.get(record.status, "pending"),
                "status_label": "À réviser" if _SCORING_STATUS.get(record.status, "pending") == "pending" else None,
                "created_at": _iso(record.date),
                "updated_at": _iso(record.date),
                "sector": record.sector,
                "filename": _liasse_file(record).name if _liasse_file(record) else None,
                "has_document": bool(_liasse_file(record)),
                "completeness_pct": float(scoring.get("dossierCompletenessPct") or 0),
                "override_count": 0,
                "motif": None,
                "comment": None,
                "decided_by": None,
                "decided_at": None,
                "identite": {
                    "raison_sociale": record.name,
                    "ice": record.ice,
                    "identifiant_fiscal": record.identifiantFiscal,
                    "activite": record.sector,
                },
                "identifiant_fiscal": record.identifiantFiscal or None,
                "activite": record.sector,
                "origin": "scoring",
            }
        )
        if items[-1]["status_label"] is None:
            from app.services.rcc_dossier_store import STATUS_LABELS

            items[-1]["status_label"] = STATUS_LABELS.get(items[-1]["status"], items[-1]["status"])
    return items


def get_or_import(dossier_id: str) -> RccDossier | None:
    existing = rcc_dossier_store.get(dossier_id)
    if existing is not None:
        return existing
    from app.services import dossier_store

    record = dossier_store.get_by_id(dossier_id)
    if record is None:
        return None
    return import_scoring_record(record)

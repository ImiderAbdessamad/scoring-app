from __future__ import annotations

import json
import logging
from decimal import Decimal

from app.core.config import settings
from app.db.repositories.sector_data_repository import sector_data_repository
from app.sector.calculations import cagr, growth_gap, normalized_index, safe_growth
from app.sector.domain import (
    CompanyAnnualPoint,
    GrowthComparisonPoint,
    NormalizedSectorPoint,
    SectorAnalysisResult,
    SectorComparableIndicator,
    SectorDataFreshness,
    SectorHeadline,
    SectorInfo,
    SectorScoringInfo,
    SectorSeriesPoint,
)
from app.sector.mapping import resolve_mapping
from app.services.sector_sync_service import freshness_for, schedule_background_refresh

logger = logging.getLogger(__name__)

REAL_GROWTH_NOTE = (
    "La croissance réelle sectorielle est affichée comme indicateur de "
    "conjoncture et n'est pas directement soustraite à la croissance nominale "
    "de l'entreprise."
)


def _usable(field, period: str) -> Decimal | None:
    if field is None:
        return None
    block = field.current if period == "current" else field.previous
    if block is None or not block.usable or block.usable_value is None:
        return None
    return Decimal(str(block.usable_value))


def _years_from_result(result) -> tuple[int | None, int | None]:
    years = list((result.years.years if result and result.years else []) or [])
    year_n = years[2] if len(years) > 2 else None
    year_n1 = years[1] if len(years) > 1 else None
    return year_n, year_n1


def _company_series(record, result) -> list[CompanyAnnualPoint]:
    if result is None:
        return []
    by_code = {f.code: f for f in (result.fields or [])}
    year_n, year_n1 = _years_from_result(result)
    points: list[CompanyAnnualPoint] = []
    if year_n1:
        va = _usable(by_code.get("VALEUR_AJOUTEE"), "previous")
        ca = _usable(by_code.get("CHIFFRE_AFFAIRES"), "previous")
        points.append(
            CompanyAnnualPoint(
                year=year_n1,
                va=float(va) if va is not None else None,
                ca=float(ca) if ca is not None else None,
                ebe=float(v) if (v := _usable(by_code.get("EBE"), "previous")) is not None else None,
                resultatExploitation=float(v)
                if (v := _usable(by_code.get("RESULTAT_EXPLOITATION"), "previous")) is not None
                else None,
                resultatNet=float(v) if (v := _usable(by_code.get("RESULTAT_NET"), "previous")) is not None else None,
                caf=float(v) if (v := _usable(by_code.get("CAF"), "previous")) is not None else None,
                vaUsable=va is not None,
                caUsable=ca is not None,
            )
        )
    if year_n:
        va = _usable(by_code.get("VALEUR_AJOUTEE"), "current")
        ca = _usable(by_code.get("CHIFFRE_AFFAIRES"), "current")
        points.append(
            CompanyAnnualPoint(
                year=year_n,
                va=float(va) if va is not None else None,
                ca=float(ca) if ca is not None else None,
                ebe=float(v) if (v := _usable(by_code.get("EBE"), "current")) is not None else None,
                resultatExploitation=float(v)
                if (v := _usable(by_code.get("RESULTAT_EXPLOITATION"), "current")) is not None
                else None,
                resultatNet=float(v) if (v := _usable(by_code.get("RESULTAT_NET"), "current")) is not None else None,
                caf=float(v) if (v := _usable(by_code.get("CAF"), "current")) is not None else None,
                vaUsable=va is not None,
                caUsable=ca is not None,
            )
        )
    return points


def _series_points(rows) -> list[SectorSeriesPoint]:
    points: list[SectorSeriesPoint] = []
    prev = None
    for row in rows:
        value = float(row.value) if row.value is not None else None
        growth = safe_growth(row.value, prev.value) if prev is not None else None
        points.append(
            SectorSeriesPoint(
                year=row.year,
                quarter=row.quarter or None,
                value=value,
                unit=row.unit,
                growthYoy=growth,
            )
        )
        prev = row
    return points


def _deterministic_summary(result: SectorAnalysisResult) -> str:
    parts: list[str] = []
    h = result.headline
    if h.nominalGrowthYoy is not None and h.latestYear:
        sign = "+" if h.nominalGrowthYoy >= 0 else ""
        parts.append(
            f"La valeur ajoutée du secteur a progressé de {sign}{h.nominalGrowthYoy:.1f} % "
            f"en valeur courante sur le dernier exercice disponible ({h.latestYear})."
        )
    elif h.latestYear:
        parts.append(f"Valeur ajoutée sectorielle disponible pour {h.latestYear}.")
    if h.realGrowthYoy is not None:
        sign = "+" if h.realGrowthYoy >= 0 else ""
        parts.append(f"En volume, la croissance est de {sign}{h.realGrowthYoy:.1f} %.")
    gap_row = next((g for g in reversed(result.growthComparison) if g.gapPp is not None), None)
    company_g = next((g for g in reversed(result.growthComparison) if g.companyGrowth is not None), None)
    if company_g and company_g.companyGrowth is not None:
        sign = "+" if company_g.companyGrowth >= 0 else ""
        parts.append(
            f"La valeur ajoutée de l’entreprise progresse de {sign}{company_g.companyGrowth:.1f} % "
            "sur la période comparable."
        )
    if gap_row and gap_row.gapPp is not None:
        sign = "+" if gap_row.gapPp >= 0 else ""
        parts.append(f"Écart nominal entreprise-secteur : {sign}{gap_row.gapPp:.1f} points.")
    return " ".join(parts) if parts else "Analyse sectorielle HCP disponible, sans commentaire de risque."


class SectorAnalysisService:
    def analyze(
        self,
        *,
        record,
        result=None,
        trigger_refresh: bool = False,
        persist_run_id: str | None = None,
    ) -> SectorAnalysisResult:
        warnings: list[str] = []
        identity = None
        if result is not None:
            identity = result.document.identity
        mapping = resolve_mapping(
            getattr(record, "sectorRaw", None) or getattr(record, "sector_raw", None),
            getattr(record, "sector", None),
            getattr(record, "sectorNormalized", None) or getattr(record, "sector_normalized", None),
            getattr(identity, "secteur", None) if identity else None,
            getattr(identity, "activite", None) if identity else None,
        )
        current_ds = sector_data_repository.get_dataset_by_external("data_12_29")
        volume_ds = sector_data_repository.get_dataset_by_external("data_12_28")
        q_ds = sector_data_repository.get_dataset_by_external("data_12_40")
        freshness_status = freshness_for(current_ds)
        if trigger_refresh and freshness_status in {"STALE", "VERY_STALE", "UNAVAILABLE"}:
            schedule_background_refresh()
        if freshness_status in {"STALE", "VERY_STALE"}:
            warnings.append("Données HCP en cache — dernière synchronisation antérieure au seuil de fraîcheur.")
        versions = []
        for ds in (current_ds, volume_ds, q_ds):
            if ds:
                versions.append(
                    {
                        "datasetId": ds.external_dataset_id,
                        "sha256": ds.resource_sha256,
                        "updatedAt": ds.source_updated_at,
                    }
                )
        freshness = SectorDataFreshness(
            status=freshness_status if freshness_status != "VERY_STALE" else "STALE",
            lastSyncAt=current_ds.last_successful_sync_at.isoformat()
            if current_ds and current_ds.last_successful_sync_at
            else None,
            lastCheckedAt=current_ds.last_checked_at.isoformat() if current_ds and current_ds.last_checked_at else None,
            source="HCP",
            datasetVersions=versions,
            cached=freshness_status in {"STALE", "VERY_STALE", "FRESH"},
        )
        scoring = SectorScoringInfo()
        sector_info = SectorInfo(
            rawActivity=mapping.raw_activity,
            code=mapping.sector_code,
            label=mapping.sector_label,
            mappingConfidence=mapping.confidence,
            mappingStatus=mapping.status,
        )
        if mapping.status == "REVIEW_REQUIRED":
            out = SectorAnalysisResult(
                status="MAPPING_REVIEW_REQUIRED",
                sector=sector_info,
                dataFreshness=freshness,
                warnings=["Classification sectorielle à confirmer."] + warnings,
                scoring=scoring,
                realGrowthNote=REAL_GROWTH_NOTE,
            )
            return self._maybe_persist(record, persist_run_id, out)
        if mapping.status != "MATCHED" or not mapping.sector_code:
            out = SectorAnalysisResult(
                status="UNAVAILABLE",
                sector=sector_info,
                dataFreshness=freshness,
                warnings=[
                    "Le secteur de l’entreprise n’a pas pu être rapproché d’une branche HCP de manière fiable."
                ]
                + warnings,
                scoring=scoring,
                realGrowthNote=REAL_GROWTH_NOTE,
            )
            return self._maybe_persist(record, persist_run_id, out)
        if current_ds is None or not current_ds.resource_sha256:
            out = SectorAnalysisResult(
                status="UNAVAILABLE",
                sector=sector_info,
                dataFreshness=SectorDataFreshness(status="UNAVAILABLE", source="HCP"),
                warnings=["Analyse sectorielle temporairement indisponible."] + warnings,
                scoring=scoring,
                realGrowthNote=REAL_GROWTH_NOTE,
            )
            return self._maybe_persist(record, persist_run_id, out)

        annual_current = _series_points(
            sector_data_repository.list_observations(
                dataset_pk=current_ds.id, sector_code=mapping.sector_code, period_type="ANNUAL"
            )
        )
        annual_real: list[SectorSeriesPoint] = []
        if volume_ds:
            annual_real = _series_points(
                sector_data_repository.list_observations(
                    dataset_pk=volume_ds.id, sector_code=mapping.sector_code, period_type="ANNUAL"
                )
            )
        quarterly: list[SectorSeriesPoint] = []
        if q_ds:
            quarterly = _series_points(
                sector_data_repository.list_observations(dataset_pk=q_ds.id, sector_code=mapping.sector_code)
            )[-12:]
        if current_ds:
            freshness.latestObservationPeriod = (
                str(annual_current[-1].year) if annual_current else None
            )
        company = _company_series(record, result)
        company_by_year = {p.year: p for p in company}
        growth_rows: list[GrowthComparisonPoint] = []
        for i, point in enumerate(annual_current):
            prev = annual_current[i - 1] if i else None
            company_point = company_by_year.get(point.year)
            prev_company = company_by_year.get(point.year - 1)
            company_growth = None
            if company_point and prev_company:
                company_growth = safe_growth(company_point.va, prev_company.va)
            growth_rows.append(
                GrowthComparisonPoint(
                    year=point.year,
                    companyGrowth=company_growth,
                    sectorGrowth=point.growthYoy,
                    gapPp=growth_gap(company_growth, point.growthYoy),
                    companyAvailable=bool(company_point and company_point.vaUsable),
                )
            )
        overlap_years = [p.year for p in annual_current if p.year in company_by_year and company_by_year[p.year].vaUsable]
        normalized: list[NormalizedSectorPoint] = []
        if overlap_years:
            base_year = overlap_years[0]
            company_vals = [company_by_year.get(y).va if company_by_year.get(y) else None for y in overlap_years]
            sector_vals = []
            for y in overlap_years:
                match = next((p.value for p in annual_current if p.year == y), None)
                sector_vals.append(match)
            c_idx = normalized_index(company_vals)
            s_idx = normalized_index(sector_vals)
            for year, ci, si in zip(overlap_years, c_idx, s_idx):
                normalized.append(NormalizedSectorPoint(year=year, companyIndex=ci, sectorIndex=si))
            del base_year
        latest = annual_current[-1] if annual_current else None
        prev_latest = annual_current[-2] if len(annual_current) > 1 else None
        real_latest = annual_real[-1] if annual_real else None
        real_prev = annual_real[-2] if len(annual_real) > 1 else None
        cagr3 = None
        if len(annual_current) >= 4:
            cagr3 = cagr(annual_current[-4].value, annual_current[-1].value, 3)
        headline = SectorHeadline(
            latestSectorVa=latest.value if latest else None,
            latestYear=latest.year if latest else None,
            latestUnit=latest.unit if latest else "M MAD",
            nominalGrowthYoy=safe_growth(latest.value, prev_latest.value) if latest and prev_latest else None,
            realGrowthYoy=safe_growth(real_latest.value, real_prev.value) if real_latest and real_prev else None,
            cagr3y=cagr3,
        )
        last_gap = next((g for g in reversed(growth_rows) if g.gapPp is not None), None)
        last_company = next((g for g in reversed(growth_rows) if g.companyGrowth is not None), None)
        comparables = [
            SectorComparableIndicator(
                code="VA_NOMINAL_GROWTH",
                label="Croissance VA nominale",
                companyValue=last_company.companyGrowth if last_company else None,
                sectorValue=headline.nominalGrowthYoy,
                unit="%",
                gap=last_gap.gapPp if last_gap else None,
                comparable=last_company is not None and headline.nominalGrowthYoy is not None,
                reason=None if last_company else "Analyse de la liasse requise",
                source="HCP comptes nationaux / ESG entreprise",
            )
        ]
        status = "AVAILABLE" if annual_current else "UNAVAILABLE"
        if status == "AVAILABLE" and (not company or all(not p.vaUsable for p in company)):
            status = "PARTIAL"
            warnings.append("Analyse de la liasse requise pour comparer l’entreprise au secteur.")
        if not annual_real:
            warnings.append("Série de volume HCP absente — croissance réelle non calculée.")
        out = SectorAnalysisResult(
            status=status,
            sector=sector_info,
            dataFreshness=freshness,
            headline=headline,
            sectorAnnualCurrent=annual_current,
            sectorAnnualReal=annual_real,
            sectorQuarterly=quarterly,
            companyAnnual=company,
            normalizedComparison=normalized,
            growthComparison=growth_rows[-8:],
            comparableIndicators=comparables,
            warnings=warnings,
            scoring=scoring,
            realGrowthNote=REAL_GROWTH_NOTE,
        )
        out.summary = _deterministic_summary(out)
        return self._maybe_persist(record, persist_run_id, out)

    def _maybe_persist(self, record, run_id: str | None, result: SectorAnalysisResult) -> SectorAnalysisResult:
        if record is None:
            return result
        try:
            sector_data_repository.save_snapshot(
                dossier_id=record.id,
                analysis_run_id=run_id,
                sector_code=result.sector.code,
                sector_label=result.sector.label,
                data_version={"freshness": result.dataFreshness.model_dump(), "datasets": result.dataFreshness.datasetVersions},
                result=result.model_dump(),
            )
        except Exception as exc:
            logger.warning("sector snapshot persist failed: %s", exc)
        return result

    def for_workspace(self, record, result) -> dict:
        try:
            analysis = self.analyze(record=record, result=result, trigger_refresh=True)
            return json.loads(analysis.model_dump_json())
        except Exception as exc:
            logger.warning("sector analysis skipped: %s", exc)
            return SectorAnalysisResult(
                status="UNAVAILABLE",
                warnings=["Analyse sectorielle temporairement indisponible."],
                scoring=SectorScoringInfo(),
            ).model_dump()


sector_analysis_service = SectorAnalysisService()
